import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Korean Café Map',
  description: 'ソウル・釜山のおしゃれカフェを地図で探す',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body className="bg-white text-gray-900">{children}</body>
    </html>
  )
}
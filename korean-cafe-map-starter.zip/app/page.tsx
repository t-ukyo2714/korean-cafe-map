'use client';
import { useEffect, useMemo, useState } from 'react';
import Map from './components/Map';

type Cafe = {
  id: string;
  name: string;
  city: 'Seoul' | 'Busan';
  address: string;
  lat: number;
  lng: number;
  photo_url?: string;
  instagram_url?: string;
  x_url?: string;
  tags: string[];
};

export default function Home() {
  const [cafes, setCafes] = useState<Cafe[]>([]);
  const [city, setCity] = useState<'All'|'Seoul'|'Busan'>('All');
  const [tag, setTag] = useState<string>('All');
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    fetch('/cafes.json').then(r => r.json()).then(setCafes).catch(() => setCafes([]));
  }, []);

  const tags = useMemo(() => {
    const t = new Set<string>();
    cafes.forEach(c => c.tags?.forEach(x => t.add(x)));
    return ['All', ...Array.from(t)];
  }, [cafes]);

  const filtered = cafes.filter(c =>
    (city === 'All' || c.city === city) &&
    (tag === 'All' || c.tags?.includes(tag))
  );

  const activeCafe = filtered.find(c => c.id === activeId) || null;

  return (
    <main className="mx-auto max-w-6xl p-4 space-y-4">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Korean Café Map｜한국 카페 맵</h1>
        <a href="/submit" className="text-sm underline">投稿 / 제보하기</a>
      </header>

      <section className="flex flex-wrap gap-3 items-center">
        <select value={city} onChange={e => setCity(e.target.value as any)} className="border rounded-xl px-3 py-2">
          <option value="All">全エリア</option>
          <option value="Seoul">ソウル</option>
          <option value="Busan">釜山</option>
        </select>
        <select value={tag} onChange={e => setTag(e.target.value)} className="border rounded-xl px-3 py-2">
          {tags.map(t => <option key={t}>{t}</option>)}
        </select>
      </section>

      <section className="grid md:grid-cols-2 gap-4">
        <div className="order-2 md:order-1 space-y-3 overflow-y-auto md:h-[60vh] pr-1">
          {filtered.map(c => (
            <article key={c.id} onClick={() => setActiveId(c.id)}
              className={\`rounded-2xl border p-3 cursor-pointer \${activeId===c.id?'ring-2 ring-black':''}\`}>
              <div className="flex gap-3">
                <img src={c.photo_url || '/placeholder.jpg'} alt={c.name} className="w-28 h-20 object-cover rounded-xl" />
                <div className="flex-1">
                  <h3 className="font-semibold">{c.name}</h3>
                  <p className="text-sm opacity-70">{c.address}</p>
                  <div className="flex gap-2 mt-1 text-sm">
                    {c.instagram_url && <a className="underline" href={c.instagram_url} target="_blank">Instagram</a>}
                    {c.x_url && <a className="underline" href={c.x_url} target="_blank">X</a>}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {c.tags?.map(t => <span key={t} className="text-xs border px-2 py-0.5 rounded-xl">{t}</span>)}
                  </div>
                </div>
              </div>
            </article>
          ))}
          {filtered.length === 0 && <p className="opacity-60">該当なし</p>}
        </div>

        <div className="order-1 md:order-2">
          <Map
            markers={filtered.map(c => ({ id: c.id, name: c.name, lat: c.lat, lng: c.lng }))}
            onMarkerClick={(id) => setActiveId(id)}
          />
        </div>
      </section>

      {activeCafe && (
        <section className="rounded-2xl border p-4">
          <h2 className="text-lg font-semibold mb-2">{activeCafe.name}</h2>
          <p className="text-sm">{activeCafe.address}</p>
          <div className="flex gap-2 mt-2 text-sm">
            {activeCafe.instagram_url && <a className="underline" href={activeCafe.instagram_url} target="_blank">Instagram</a>}
            {activeCafe.x_url && <a className="underline" href={activeCafe.x_url} target="_blank">X</a>}
          </div>
          <img src={activeCafe.photo_url || '/placeholder.jpg'} alt={activeCafe.name} className="w-full h-64 object-cover rounded-xl mt-3" />
        </section>
      )}
    </main>
  );
}
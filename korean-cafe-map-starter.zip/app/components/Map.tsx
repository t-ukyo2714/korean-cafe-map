'use client';
import { useEffect, useRef } from 'react';

type Marker = { id: string; name: string; lat: number; lng: number; };
type Props = {
  markers: Marker[];
  onMarkerClick?: (id: string) => void;
  center?: { lat: number; lng: number };
  zoom?: number;
};

export default function Map({ markers, onMarkerClick, center = { lat: 37.5665, lng: 126.9780 }, zoom = 12 }: Props) {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const mapObj = useRef<google.maps.Map | null>(null);
  const markerObjs = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    const scriptId = 'gmaps-script';
    const existing = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!existing) {
      const s = document.createElement('script');
      s.id = scriptId;
      s.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&libraries=marker`;
      s.async = true;
      document.head.appendChild(s);
      s.onload = init;
    } else if (existing && !('google' in window)) {
      existing.onload = init;
    } else {
      init();
    }

    function init() {
      if (!mapRef.current) return;
      if (!mapObj.current) {
        mapObj.current = new google.maps.Map(mapRef.current, {
          center,
          zoom,
          mapTypeControl: false,
          fullscreenControl: false,
        });
      }
      markerObjs.current.forEach(m => m.setMap(null));
      markerObjs.current = [];

      markers.forEach((m) => {
        const marker = new google.maps.Marker({
          position: { lat: m.lat, lng: m.lng },
          map: mapObj.current!,
          title: m.name,
        });
        marker.addListener('click', () => onMarkerClick?.(m.id));
        markerObjs.current.push(marker);
      });

      if (markers.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        markers.forEach(m => bounds.extend({ lat: m.lat, lng: m.lng }));
        mapObj.current.fitBounds(bounds);
      }
    }
  }, [markers, center?.lat, center?.lng, zoom]);

  return <div ref={mapRef} className="w-full h-[60vh] rounded-2xl border" />;
}
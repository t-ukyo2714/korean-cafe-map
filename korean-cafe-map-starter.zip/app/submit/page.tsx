export default function Submit() {
  return (
    <main className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">カフェ投稿</h1>
      <p className="mb-2 text-sm opacity-80">以下のフォームからおすすめカフェを教えてください。</p>
      <iframe
        src="https://tally.so/r/your-form-id"
        width="100%"
        height="600"
        frameBorder="0"
        title="投稿フォーム"
      />
    </main>
  );
}